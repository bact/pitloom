import asyncio
import contextvars
import inspect
import os
import sys
from functools import wraps
from typing import (
    Any,
    AsyncGenerator,
    Callable,
    Dict,
    Generator,
    Iterable,
    List,
    Optional,
    Tuple,
    TypeVar,
    Union,
    cast,
    overload,
)

from opentelemetry.util._decorator import _AgnosticContextManager
from typing_extensions import ParamSpec

from langfuse._client.constants import (
    ObservationTypeLiteralNoEvent,
    get_observation_types_list,
)
from langfuse._client.environment_variables import (
    LANGFUSE_OBSERVE_DECORATOR_IO_CAPTURE_ENABLED,
)
from langfuse._client.get_client import _set_current_public_key, get_client
from langfuse._client.span import (
    LangfuseAgent,
    LangfuseChain,
    LangfuseEmbedding,
    LangfuseEvaluator,
    LangfuseGeneration,
    LangfuseGuardrail,
    LangfuseRetriever,
    LangfuseSpan,
    LangfuseTool,
)
from langfuse.logger import langfuse_logger as logger
from langfuse.types import TraceContext

F = TypeVar("F", bound=Callable[..., Any])
P = ParamSpec("P")
R = TypeVar("R")

_ASYNCIO_CREATE_TASK_SUPPORTS_CONTEXT = sys.version_info >= (3, 11)


class LangfuseDecorator:
    """Implementation of the @observe decorator for seamless Langfuse tracing integration.

    This class provides the core functionality for the @observe decorator, which enables
    automatic tracing of functions and methods in your application with Langfuse.
    It handles both synchronous and asynchronous functions, maintains proper trace context,
    and intelligently routes to the correct Langfuse client instance.

    The implementation follows a singleton pattern where a single decorator instance
    handles all @observe decorations throughout the application codebase.

    Features:
    - Automatic span creation and management for both sync and async functions
    - Proper trace context propagation between decorated functions
    - Specialized handling for LLM-related spans with the 'as_type="generation"' parameter
    - Type-safe decoration that preserves function signatures and type hints
    - Support for explicit trace and parent span ID specification
    - Thread-safe client resolution when multiple Langfuse projects are used
    """

    @overload
    def observe(self, func: F) -> F: ...

    @overload
    def observe(
        self,
        func: None = None,
        *,
        name: Optional[str] = None,
        as_type: Optional[ObservationTypeLiteralNoEvent] = None,
        capture_input: Optional[bool] = None,
        capture_output: Optional[bool] = None,
        transform_to_string: Optional[Callable[[Iterable], str]] = None,
    ) -> Callable[[F], F]: ...

    def observe(
        self,
        func: Optional[F] = None,
        *,
        name: Optional[str] = None,
        as_type: Optional[ObservationTypeLiteralNoEvent] = None,
        capture_input: Optional[bool] = None,
        capture_output: Optional[bool] = None,
        transform_to_string: Optional[Callable[[Iterable], str]] = None,
    ) -> Union[F, Callable[[F], F]]:
        """Wrap a function to create and manage Langfuse tracing around its execution, supporting both synchronous and asynchronous functions.

        This decorator provides seamless integration of Langfuse observability into your codebase. It automatically creates
        spans or generations around function execution, capturing timing, inputs/outputs, and error states. The decorator
        intelligently handles both synchronous and asynchronous functions, preserving function signatures and type hints.

        Using OpenTelemetry's distributed tracing system, it maintains proper trace context propagation throughout your application,
        enabling you to see hierarchical traces of function calls with detailed performance metrics and function-specific details.

        Args:
            func (Optional[Callable]): The function to decorate. When used with parentheses @observe(), this will be None.
            name (Optional[str]): Custom name for the created trace or span. If not provided, the function name is used.
            as_type (Optional[Literal]): Set the observation type. Supported values:
                    "generation", "span", "agent", "tool", "chain", "retriever", "embedding", "evaluator", "guardrail".
                    Observation types are highlighted in the Langfuse UI for filtering and visualization.
                    The types "generation" and "embedding" create a span on which additional attributes such as model,
                    usage_details, and cost_details can be set — use `as_type="generation"` for LLM calls and update the
                    observation via `langfuse.update_current_generation(...)` inside the function.
            capture_input (Optional[bool]): Whether to capture the function's arguments as the observation's input.
                    Defaults to the LANGFUSE_OBSERVE_DECORATOR_IO_CAPTURE_ENABLED environment variable (True if unset).
                    Set to False for sensitive or very large inputs, then set input explicitly via
                    `langfuse.update_current_span(input=...)` if needed.
            capture_output (Optional[bool]): Whether to capture the function's return value as the observation's output.
                    Same default and override mechanism as capture_input.
            transform_to_string (Optional[Callable[[Iterable], str]]): For functions returning generators, joins the
                    yielded chunks into the string stored as output. Without it, chunks are concatenated if all are
                    strings, otherwise stored as a list.

        Returns:
            Callable: A wrapped version of the original function that automatically creates and manages Langfuse spans.

        Example:
            For general function tracing with automatic naming:
            ```python
            @observe()
            def process_user_request(user_id, query):
                # Function is automatically traced with name "process_user_request"
                return get_response(query)
            ```

            For language model generation tracking:
            ```python
            from langfuse import get_client, observe

            @observe(name="answer-generation", as_type="generation")
            async def generate_answer(query):
                # Creates a generation-type observation with extended LLM metrics
                response = await openai.chat.completions.create(
                    model="gpt-4",
                    messages=[{"role": "user", "content": query}]
                )
                return response.choices[0].message.content
            ```

            Disabling input/output capture (e.g. for sensitive or large payloads):
            ```python
            @observe(capture_input=False, capture_output=False)
            def handle_pii(user_record):
                return process(user_record)
            ```

            For trace context propagation between functions:
            ```python
            @observe()
            def main_process():
                # Parent span is created
                return sub_process()  # Child span automatically connected to parent

            @observe()
            def sub_process():
                # Automatically becomes a child span of main_process
                return "result"
            ```

        Raises:
            Exception: Propagates any exceptions from the wrapped function after logging them in the trace.

        Notes:
            - The decorator preserves the original function's signature, docstring, and return type.
            - Proper parent-child relationships between spans are automatically maintained.
            - Special keyword arguments can be passed to control tracing:
              - langfuse_trace_id: Explicitly set the trace ID for this function call
              - langfuse_parent_observation_id: Explicitly set the parent span ID
              - langfuse_public_key: Use a specific Langfuse project (when multiple clients exist)
            - For async functions, the decorator returns an async function wrapper.
            - For sync functions, the decorator returns a synchronous wrapper.
        """
        valid_types = set(get_observation_types_list(ObservationTypeLiteralNoEvent))
        if as_type is not None and as_type not in valid_types:
            logger.warning(
                "Invalid as_type '%s'. Valid types are: %s. Defaulting to 'span'.",
                as_type,
                ", ".join(sorted(valid_types)),
            )
            as_type = "span"

        function_io_capture_enabled = os.environ.get(
            LANGFUSE_OBSERVE_DECORATOR_IO_CAPTURE_ENABLED, "True"
        ).lower() not in ("false", "0")

        should_capture_input = (
            capture_input if capture_input is not None else function_io_capture_enabled
        )

        should_capture_output = (
            capture_output
            if capture_output is not None
            else function_io_capture_enabled
        )

        def decorator(func: F) -> F:
            return (
                self._async_observe(
                    func,
                    name=name,
                    as_type=as_type,
                    capture_input=should_capture_input,
                    capture_output=should_capture_output,
                    transform_to_string=transform_to_string,
                )
                if asyncio.iscoroutinefunction(func)
                else self._sync_observe(
                    func,
                    name=name,
                    as_type=as_type,
                    capture_input=should_capture_input,
                    capture_output=should_capture_output,
                    transform_to_string=transform_to_string,
                )
            )

        """Handle decorator with or without parentheses.

        This logic enables the decorator to work both with and without parentheses:
        - @observe - Python passes the function directly to the decorator
        - @observe() - Python calls the decorator first, which must return a function decorator

        When called without arguments (@observe), the func parameter contains the function to decorate,
        so we directly apply the decorator to it. When called with parentheses (@observe()),
        func is None, so we return the decorator function itself for Python to apply in the next step.
        """
        if func is None:
            return decorator
        else:
            return decorator(func)

    def _async_observe(
        self,
        func: F,
        *,
        name: Optional[str],
        as_type: Optional[ObservationTypeLiteralNoEvent],
        capture_input: bool,
        capture_output: bool,
        transform_to_string: Optional[Callable[[Iterable], str]] = None,
    ) -> F:
        @wraps(func)
        async def async_wrapper(*args: Tuple[Any], **kwargs: Dict[str, Any]) -> Any:
            trace_id = cast(str, kwargs.pop("langfuse_trace_id", None))
            parent_observation_id = cast(
                str, kwargs.pop("langfuse_parent_observation_id", None)
            )
            trace_context: Optional[TraceContext] = (
                {
                    "trace_id": trace_id,
                    "parent_span_id": parent_observation_id,
                }
                if trace_id
                else None
            )
            final_name = name or func.__name__
            input = (
                self._get_input_from_func_args(
                    is_method=self._is_method(func),
                    func_args=args,
                    func_kwargs=kwargs,
                )
                if capture_input
                else None
            )
            public_key = cast(str, kwargs.pop("langfuse_public_key", None))

            # Set public key in execution context for nested decorated functions
            with _set_current_public_key(public_key):
                langfuse_client = get_client(public_key=public_key)
                context_manager: Optional[
                    Union[
                        _AgnosticContextManager[LangfuseGeneration],
                        _AgnosticContextManager[LangfuseSpan],
                        _AgnosticContextManager[LangfuseAgent],
                        _AgnosticContextManager[LangfuseTool],
                        _AgnosticContextManager[LangfuseChain],
                        _AgnosticContextManager[LangfuseRetriever],
                        _AgnosticContextManager[LangfuseEvaluator],
                        _AgnosticContextManager[LangfuseEmbedding],
                        _AgnosticContextManager[LangfuseGuardrail],
                    ]
                ] = (
                    langfuse_client.start_as_current_observation(
                        name=final_name,
                        as_type=as_type or "span",
                        trace_context=trace_context,
                        input=input,
                        end_on_exit=False,  # when returning a generator, closing on exit would be to early
                    )
                    if langfuse_client
                    else None
                )

                if context_manager is None:
                    return await func(*args, **kwargs)

                with context_manager as langfuse_span_or_generation:
                    is_return_type_generator = False

                    try:
                        result = await func(*args, **kwargs)
                        (
                            is_return_type_generator,
                            result,
                        ) = self._handle_observe_result(
                            langfuse_span_or_generation,
                            result,
                            capture_output=capture_output,
                            transform_to_string=transform_to_string,
                        )
                        return result
                    except (Exception, asyncio.CancelledError) as e:
                        langfuse_span_or_generation.update(
                            level="ERROR", status_message=str(e) or type(e).__name__
                        )

                        raise e
                    finally:
                        if not is_return_type_generator:
                            langfuse_span_or_generation.end()

        return cast(F, async_wrapper)

    def _sync_observe(
        self,
        func: F,
        *,
        name: Optional[str],
        as_type: Optional[ObservationTypeLiteralNoEvent],
        capture_input: bool,
        capture_output: bool,
        transform_to_string: Optional[Callable[[Iterable], str]] = None,
    ) -> F:
        @wraps(func)
        def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
            trace_id = kwargs.pop("langfuse_trace_id", None)
            parent_observation_id = kwargs.pop("langfuse_parent_observation_id", None)
            trace_context: Optional[TraceContext] = (
                {
                    "trace_id": trace_id,
                    "parent_span_id": parent_observation_id,
                }
                if trace_id
                else None
            )
            final_name = name or func.__name__
            input = (
                self._get_input_from_func_args(
                    is_method=self._is_method(func),
                    func_args=args,
                    func_kwargs=kwargs,
                )
                if capture_input
                else None
            )
            public_key = kwargs.pop("langfuse_public_key", None)

            # Set public key in execution context for nested decorated functions
            with _set_current_public_key(public_key):
                langfuse_client = get_client(public_key=public_key)
                context_manager: Optional[
                    Union[
                        _AgnosticContextManager[LangfuseGeneration],
                        _AgnosticContextManager[LangfuseSpan],
                        _AgnosticContextManager[LangfuseAgent],
                        _AgnosticContextManager[LangfuseTool],
                        _AgnosticContextManager[LangfuseChain],
                        _AgnosticContextManager[LangfuseRetriever],
                        _AgnosticContextManager[LangfuseEvaluator],
                        _AgnosticContextManager[LangfuseEmbedding],
                        _AgnosticContextManager[LangfuseGuardrail],
                    ]
                ] = (
                    langfuse_client.start_as_current_observation(
                        name=final_name,
                        as_type=as_type or "span",
                        trace_context=trace_context,
                        input=input,
                        end_on_exit=False,  # when returning a generator, closing on exit would be to early
                    )
                    if langfuse_client
                    else None
                )

                if context_manager is None:
                    return func(*args, **kwargs)

                with context_manager as langfuse_span_or_generation:
                    is_return_type_generator = False

                    try:
                        result = func(*args, **kwargs)
                        (
                            is_return_type_generator,
                            result,
                        ) = self._handle_observe_result(
                            langfuse_span_or_generation,
                            result,
                            capture_output=capture_output,
                            transform_to_string=transform_to_string,
                        )
                        return result
                    except (Exception, asyncio.CancelledError) as e:
                        langfuse_span_or_generation.update(
                            level="ERROR", status_message=str(e) or type(e).__name__
                        )

                        raise e
                    finally:
                        if not is_return_type_generator:
                            langfuse_span_or_generation.end()

        return cast(F, sync_wrapper)

    @staticmethod
    def _is_method(func: Callable) -> bool:
        return (
            "self" in inspect.signature(func).parameters
            or "cls" in inspect.signature(func).parameters
        )

    def _get_input_from_func_args(
        self,
        *,
        is_method: bool = False,
        func_args: Tuple = (),
        func_kwargs: Dict = {},
    ) -> Dict:
        # Remove implicitly passed "self" or "cls" argument for instance or class methods
        logged_args = func_args[1:] if is_method else func_args

        return {
            "args": logged_args,
            "kwargs": func_kwargs,
        }

    def _wrap_sync_generator_result(
        self,
        langfuse_span_or_generation: Union[
            LangfuseSpan,
            LangfuseGeneration,
            LangfuseAgent,
            LangfuseTool,
            LangfuseChain,
            LangfuseRetriever,
            LangfuseEvaluator,
            LangfuseEmbedding,
            LangfuseGuardrail,
        ],
        generator: Generator,
        capture_output: bool,
        transform_to_string: Optional[Callable[[Iterable], str]] = None,
    ) -> Any:
        preserved_context = contextvars.copy_context()

        return _ContextPreservedSyncGeneratorWrapper(
            generator,
            preserved_context,
            langfuse_span_or_generation,
            capture_output,
            transform_to_string,
        )

    def _wrap_async_generator_result(
        self,
        langfuse_span_or_generation: Union[
            LangfuseSpan,
            LangfuseGeneration,
            LangfuseAgent,
            LangfuseTool,
            LangfuseChain,
            LangfuseRetriever,
            LangfuseEvaluator,
            LangfuseEmbedding,
            LangfuseGuardrail,
        ],
        generator: AsyncGenerator,
        capture_output: bool,
        transform_to_string: Optional[Callable[[Iterable], str]] = None,
    ) -> Any:
        preserved_context = contextvars.copy_context()

        return _ContextPreservedAsyncGeneratorWrapper(
            generator,
            preserved_context,
            langfuse_span_or_generation,
            capture_output,
            transform_to_string,
        )

    def _handle_observe_result(
        self,
        langfuse_span_or_generation: Union[
            LangfuseSpan,
            LangfuseGeneration,
            LangfuseAgent,
            LangfuseTool,
            LangfuseChain,
            LangfuseRetriever,
            LangfuseEvaluator,
            LangfuseEmbedding,
            LangfuseGuardrail,
        ],
        result: Any,
        *,
        capture_output: bool,
        transform_to_string: Optional[Callable[[Iterable], str]] = None,
    ) -> Tuple[bool, Any]:
        if inspect.isgenerator(result):
            return True, self._wrap_sync_generator_result(
                langfuse_span_or_generation,
                result,
                capture_output,
                transform_to_string,
            )

        if inspect.isasyncgen(result):
            return True, self._wrap_async_generator_result(
                langfuse_span_or_generation,
                result,
                capture_output,
                transform_to_string,
            )

        # handle starlette.StreamingResponse
        if type(result).__name__ == "StreamingResponse" and hasattr(
            result, "body_iterator"
        ):
            result.body_iterator = self._wrap_async_generator_result(
                langfuse_span_or_generation,
                result.body_iterator,
                capture_output,
                transform_to_string,
            )
            return True, result

        if capture_output is True:
            langfuse_span_or_generation.update(output=result)

        return False, result


_decorator = LangfuseDecorator()

observe = _decorator.observe


class _ContextPreservedSyncGeneratorWrapper:
    """Sync generator wrapper that ensures each iteration runs in preserved context."""

    def __init__(
        self,
        generator: Generator,
        context: contextvars.Context,
        span: Union[
            LangfuseSpan,
            LangfuseGeneration,
            LangfuseAgent,
            LangfuseTool,
            LangfuseChain,
            LangfuseRetriever,
            LangfuseEvaluator,
            LangfuseEmbedding,
            LangfuseGuardrail,
        ],
        capture_output: bool,
        transform_fn: Optional[Callable[[Iterable], str]],
    ) -> None:
        self.generator = generator
        self.context = context
        self.items: List[Any] = []
        self.span = span
        self.capture_output = capture_output
        self.transform_fn = transform_fn
        self._span_ended = False

    def __iter__(self) -> "_ContextPreservedSyncGeneratorWrapper":
        return self

    def _finalize(self) -> None:
        if self._span_ended:
            return

        if self.capture_output:
            output: Any = self.items

            if self.transform_fn is not None:
                output = self.transform_fn(self.items)

            elif all(isinstance(item, str) for item in self.items):
                output = "".join(self.items)

            self.span.update(output=output)

        self.span.end()
        self._span_ended = True

    def _finalize_with_error(self, error: BaseException) -> None:
        if self._span_ended:
            return

        self.span.update(
            level="ERROR", status_message=str(error) or type(error).__name__
        ).end()
        self._span_ended = True

    def close(self) -> None:
        if self._span_ended:
            # Still close the generator so cleanup runs in the preserved context, not at GC time.
            self.context.run(self.generator.close)
            return

        try:
            self.context.run(self.generator.close)
        except (Exception, asyncio.CancelledError) as error:
            self._finalize_with_error(error)
            raise
        else:
            self._finalize()

    def __del__(self) -> None:
        try:
            self.close()
        except BaseException:
            pass

    def __next__(self) -> Any:
        try:
            # Run the generator's __next__ in the preserved context
            item = self.context.run(next, self.generator)
            if self.capture_output:
                self.items.append(item)

            return item

        except StopIteration:
            self._finalize()
            raise  # Re-raise StopIteration

        except (Exception, asyncio.CancelledError) as e:
            self._finalize_with_error(e)
            raise


class _ContextPreservedAsyncGeneratorWrapper:
    """Async generator wrapper that ensures each iteration runs in preserved context."""

    def __init__(
        self,
        generator: AsyncGenerator,
        context: contextvars.Context,
        span: Union[
            LangfuseSpan,
            LangfuseGeneration,
            LangfuseAgent,
            LangfuseTool,
            LangfuseChain,
            LangfuseRetriever,
            LangfuseEvaluator,
            LangfuseEmbedding,
            LangfuseGuardrail,
        ],
        capture_output: bool,
        transform_fn: Optional[Callable[[Iterable], str]],
    ) -> None:
        self.generator = generator
        self.context = context
        self.items: List[Any] = []
        self.span = span
        self.capture_output = capture_output
        self.transform_fn = transform_fn
        self._span_ended = False
        self._pending_error: Optional[BaseException] = None

    def __aiter__(self) -> "_ContextPreservedAsyncGeneratorWrapper":
        return self

    def _generator_never_resumed(self) -> bool:
        try:
            state = inspect.getasyncgenstate(self.generator)
        except (AttributeError, TypeError):
            # getasyncgenstate is Python 3.12+; fall back to the attributes it reads.
            frame = getattr(self.generator, "ag_frame", None)
            return frame is not None and not getattr(
                self.generator, "ag_running", False
            )

        return state in ("AGEN_CREATED", "AGEN_SUSPENDED")

    def _finalize(self) -> None:
        if self._span_ended:
            return

        if self.capture_output:
            output: Any = self.items

            if self.transform_fn is not None:
                output = self.transform_fn(self.items)

            elif all(isinstance(item, str) for item in self.items):
                output = "".join(self.items)

            self.span.update(output=output)

        self.span.end()
        self._span_ended = True

    def _finalize_with_error(self, error: BaseException) -> None:
        if self._span_ended:
            return

        self.span.update(
            level="ERROR", status_message=str(error) or type(error).__name__
        ).end()
        self._span_ended = True

    async def aclose(self) -> None:
        if self._span_ended:
            # Still close the generator so cleanup runs in the preserved context, not at GC time.
            await self._close_generator()
            return

        try:
            await self._close_generator()
        except (Exception, asyncio.CancelledError) as error:
            self._finalize_with_error(error)
            raise
        else:
            if self._pending_error is not None:
                self._finalize_with_error(self._pending_error)
            else:
                self._finalize()

    async def _close_generator(self) -> None:
        if _ASYNCIO_CREATE_TASK_SUPPORTS_CONTEXT:
            close_task = asyncio.create_task(
                self.generator.aclose(),
                context=self.context,
            )  # type: ignore
        else:
            close_task = self.context.run(asyncio.create_task, self.generator.aclose())

        await close_task

    async def close(self) -> None:
        await self.aclose()

    def __del__(self) -> None:
        if self._pending_error is not None:
            self._finalize_with_error(self._pending_error)
        else:
            self._finalize()

    async def __anext__(self) -> Any:
        try:
            # Run the generator's __anext__ in the preserved context
            if _ASYNCIO_CREATE_TASK_SUPPORTS_CONTEXT:
                item = await asyncio.create_task(
                    self.generator.__anext__(),  # type: ignore
                    context=self.context,
                )  # type: ignore
            else:
                item = await self.context.run(
                    asyncio.create_task,
                    self.generator.__anext__(),  # type: ignore
                )

            if self.capture_output:
                self.items.append(item)

            return item

        except StopAsyncIteration:
            self._finalize()
            raise  # Re-raise StopAsyncIteration
        except asyncio.CancelledError as e:
            if self._generator_never_resumed():
                # Defer span end so aclose() can run the generator's cleanup first.
                self._pending_error = e
                raise
            self._finalize_with_error(e)
            raise
        except Exception as e:
            self._finalize_with_error(e)
            raise
