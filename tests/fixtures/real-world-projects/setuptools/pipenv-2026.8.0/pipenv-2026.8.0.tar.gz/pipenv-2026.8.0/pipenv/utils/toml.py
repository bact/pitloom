from typing import Union

from pipenv.vendor.plette.models import Package, PackageCollection
from pipenv.vendor.tomlkit.container import Container, OutOfOrderTableProxy
from pipenv.vendor.tomlkit.items import AoT, Array, Bool, InlineTable, Item, String, Table
from pipenv.vendor.tomlkit.toml_document import TOMLDocument

try:
    import tomllib as toml
except ImportError:
    from pipenv.patched.pip._vendor import tomli as toml

from pipenv.vendor import tomlkit

TOML_DICT_TYPES = Union[Container, Package, PackageCollection, Table, InlineTable]
TOML_DICT_OBJECTS = (Container, Package, Table, InlineTable, PackageCollection)
TOML_DICT_NAMES = [o.__class__.__name__ for o in TOML_DICT_OBJECTS]


def cleanup_toml(tml):
    """Normalise whitespace in a serialised TOML string.

    * Collapse multiple consecutive blank lines into a single blank line,
      preserving intentional spacing (e.g. visual grouping of packages
      within a section) that the user placed in the Pipfile.
    * Ensure exactly one blank line appears before every section header
      (lines that start with ``[``).
    * Strip trailing blank lines and end the file with a single newline.
    """
    lines = tml.split("\n")
    new_toml = []
    prev_blank = False

    for i, line in enumerate(lines):
        is_blank = not line.strip()
        is_section_header = line.startswith("[")

        if is_blank and prev_blank:
            # Collapse consecutive blank lines into a single one.
            continue

        if is_section_header and i > 0 and not prev_blank:
            # Ensure there is exactly one blank line before every section header.
            new_toml.append("")

        new_toml.append(line)
        prev_blank = is_blank

    # Remove trailing blank lines, then add exactly one newline at the end.
    while new_toml and not new_toml[-1].strip():
        new_toml.pop()
    new_toml.append("")
    return "\n".join(new_toml)


def convert_toml_outline_tables(parsed: TOMLDocument, project) -> TOMLDocument:
    """Converts all outline tables to inline tables."""

    def convert_tomlkit_table(section):
        result: Table = tomlkit.table()
        if isinstance(section, Table):
            body = section.value._body
        elif isinstance(section, OutOfOrderTableProxy):
            body = section._internal_container._body
        else:
            assert not hasattr(section, "_body")
            body = section

        index: int = 0
        for key, value in body:
            if key is None:
                # Preserve whitespace and comment items so that blank lines
                # intentionally placed by the user within a section survive
                # a Pipfile rewrite (Table.append(None, item) is supported
                # by tomlkit's Container and does not add a dict entry).
                result.append(key, value)
                continue
            if hasattr(value, "keys") and not isinstance(value, InlineTable):
                table = tomlkit.inline_table()
                table.update(value.value)
                key.sep = " = "  # add separator because it did not exist before
                result.append(key, table)
            else:
                result.append(key, value)
            index += 1

        return result

    def convert_toml_table(section):
        result = section.copy()
        for package, value in section.items():
            if hasattr(value, "keys") and not isinstance(
                value, toml.decoder.InlineTableDict
            ):
                table = toml.TomlDecoder().get_empty_inline_table()
                table.update(value)
                result[package] = table
        return result

    is_tomlkit_parsed = isinstance(parsed, Container)
    for section in project.pipfile.get_package_categories():
        table_data = parsed.get(section, {})
        if table_data is None:
            continue
        if is_tomlkit_parsed:
            result = convert_tomlkit_table(table_data)
        else:
            result = convert_toml_table(table_data)

        parsed[section] = result
    return parsed


def tomlkit_value_to_python(toml_value):
    # type: (Union[Array, AoT, TOML_DICT_TYPES, Item]) -> Union[List, Dict]
    value_type = type(toml_value).__name__
    if (
        isinstance(toml_value, TOML_DICT_OBJECTS + (dict,))
        or value_type in TOML_DICT_NAMES
    ):
        return tomlkit_dict_to_python(toml_value)
    elif isinstance(toml_value, AoT) or value_type == "AoT":
        return [tomlkit_value_to_python(val) for val in toml_value._body]
    elif isinstance(toml_value, Array) or value_type == "Array":
        return [tomlkit_value_to_python(val) for val in list(toml_value)]
    elif isinstance(toml_value, String) or value_type == "String":
        return f"{toml_value!s}"
    elif isinstance(toml_value, Bool) or value_type == "Bool":
        return toml_value.value
    elif isinstance(toml_value, Item):
        return toml_value.value
    return toml_value


def tomlkit_dict_to_python(toml_dict):
    # type: (TOML_DICT_TYPES) -> Dict
    value_type = type(toml_dict).__name__
    if toml_dict is None:
        raise TypeError("Invalid type NoneType when converting toml dict to python")
    converted = None  # type: Optional[Dict]
    if isinstance(toml_dict, (InlineTable, Table)) or value_type in (
        "InlineTable",
        "Table",
    ):
        converted = toml_dict.value
    elif isinstance(toml_dict, (Package, PackageCollection)) or value_type in (
        "Package, PackageCollection"
    ):
        converted = toml_dict._data
        if isinstance(converted, Container) or type(converted).__name__ == "Container":
            converted = converted.value
    elif isinstance(toml_dict, Container) or value_type == "Container":
        converted = toml_dict.value
    elif isinstance(toml_dict, dict):
        converted = toml_dict.copy()
    else:
        raise TypeError(
            f"Invalid type for conversion: expected Container, Dict, or Table, got {toml_dict}"
        )
    if isinstance(converted, dict):
        return {k: tomlkit_value_to_python(v) for k, v in converted.items()}
    elif isinstance(converted, (TOML_DICT_OBJECTS)) or value_type in TOML_DICT_NAMES:
        return tomlkit_dict_to_python(converted)
    return converted
