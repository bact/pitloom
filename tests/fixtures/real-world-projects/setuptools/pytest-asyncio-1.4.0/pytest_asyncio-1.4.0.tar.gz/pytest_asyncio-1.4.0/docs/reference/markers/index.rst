=======
Markers
=======

.. _reference/markers/asyncio:

``pytest.mark.asyncio``
=======================
A coroutine or async generator with this marker is treated as a test function by pytest.
The marked function is executed as an asyncio task in the event loop provided by pytest-asyncio.

Multiple async tests in a single class or module can be marked in different ways:

.. tabs::

   .. tab:: decorator

      .. include:: function_scoped_loop_strict_mode_example.py
         :code: python

   .. tab:: pytestmark

      .. include:: function_scoped_loop_pytestmark_strict_mode_example.py
         :code: python

The ``pytest.mark.asyncio`` marker can be omitted entirely in |auto mode|_ where the *asyncio* marker is added automatically to *async* test functions.

By default, each test runs in its own asyncio event loop.
Multiple tests can share the same event loop by providing a *loop_scope* keyword argument to the *asyncio* mark.
The supported scopes are *function*, *class*, *module*, *package*, and *session*.

The following code example provides a shared event loop for all tests in ``TestClassScopedLoop``:

.. include:: class_scoped_loop_strict_mode_example.py
    :code: python

Similar to class-scoped event loops, a module-scoped loop is provided when setting mark's scope to *module*:

.. include:: module_scoped_loop_strict_mode_example.py
    :code: python

Subpackages do not share the loop with their parent package.

Tests marked with *session* scope share the same event loop, even if the tests exist in different packages.

The ``pytest.mark.asyncio`` marker also accepts a ``loop_factories`` keyword argument to select a subset of configured event loop factories for a test. If ``loop_factories`` contains names not available from the hook, those test variants are skipped.

.. |auto mode| replace:: *auto mode*
.. _auto mode: ../../concepts.html#auto-mode
.. |pytestmark| replace:: ``pytestmark``
.. _pytestmark: http://doc.pytest.org/en/latest/example/markers.html#marking-whole-classes-or-modules
