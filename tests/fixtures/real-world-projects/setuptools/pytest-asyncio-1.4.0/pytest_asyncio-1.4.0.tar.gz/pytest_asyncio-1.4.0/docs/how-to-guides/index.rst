=============
How-To Guides
=============

.. toctree::
  :hidden:

  migrate_from_0_21
  migrate_from_0_23
  change_fixture_loop
  change_default_fixture_loop
  change_default_test_loop
  custom_loop_factory
  configure_loop_factories_per_test
  run_test_with_specific_loop_factories
  run_class_tests_in_same_loop
  run_module_tests_in_same_loop
  run_package_tests_in_same_loop
  multiple_loops
  parametrize_with_asyncio
  uvloop
  test_item_is_async

This section of the documentation provides code snippets and recipes to accomplish specific tasks with pytest-asyncio.
